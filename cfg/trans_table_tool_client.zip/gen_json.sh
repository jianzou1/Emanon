#!/bin/bash
for f in $(find ./ -name '*.xlsx');
do
  dir_name="$(dirname "${temp}")"
  base_name="$(basename "${temp}")"
  if [[ ${dir_name} == "/ServerConfig" ]] || [[ ${base_name} == "~"* ]]; then
    echo "Skip file: " ${temp}
  else
    ./excel2json/excel2json.exe -i $f -j ./ -t client_only
  fi
done
read -p "Press enter to continue"