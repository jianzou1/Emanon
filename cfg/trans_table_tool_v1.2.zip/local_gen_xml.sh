#!/bin/bash
for f in $(find ./ -name '*.xlsx');
do
  dir_name="$(dirname "$f")"
  base_name="$(basename "$f")"
  if [[ ${dir_name} == "./ServerConfig" ]] || [[ ${base_name} == "~"* ]]; then
    echo "Skip file: $f"
  else
    ./excel2json/excel2json.exe -i "$f" -x . -t server_only
  fi
done
read -p "Press enter to continue"