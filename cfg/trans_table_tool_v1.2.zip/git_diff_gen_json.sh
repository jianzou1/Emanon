git_dir="D:/pgunity"  # 填写git仓库根目录
original_dir=$(pwd)

cd "$git_dir" || { echo "无法进入目录: $git_dir"; exit 1; }

git_diff_files=$(git diff --name-only --diff-filter=d HEAD | grep '\.xlsx$')

for file in $git_diff_files; do
    base_name=$(basename "$file")
    
    if [[ "$base_name" == "~"* ]]; then
        echo "跳过临时文件: $file"
    else
        "$original_dir/excel2json/excel2json.exe" -i "$file" -j "$original_dir" -t client_only
    fi
done

cd "$original_dir"
read -p "JSON转换完成，按回车键继续..."